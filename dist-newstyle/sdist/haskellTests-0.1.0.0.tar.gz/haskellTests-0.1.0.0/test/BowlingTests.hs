module BowlingTests where

import Bowling
import Test.HUnit
import Test.QuickCheck

-- Test cases for toFrames
testToFramesOpen :: Test
testToFramesOpen = TestCase $ do
    assertEqual "Should create an Open frame" (Just [Open 3 4]) (toFrames [3, 4])

testToFramesSpare :: Test
testToFramesSpare = TestCase $ do
    assertEqual "Should create a Spare frame" (Just [Spare 5 5]) (toFrames [5, 5, 3])

testToFramesStrike :: Test
testToFramesStrike = TestCase $ do
    assertEqual "Should create a Strike frame" (Just [Strike 3 4]) (toFrames [10, 3, 4])

testToFramesInvalid :: Test
testToFramesInvalid = TestCase $ do
    assertEqual "Should return Nothing for invalid frame" Nothing (toFrames [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10])

-- Test cases for frameScore
testFrameScoreOpen :: Test
testFrameScoreOpen = TestCase $ do
    assertEqual "Should calculate score for Open frame" 7 (frameScore (Open 3 4))

testFrameScoreSpare :: Test
testFrameScoreSpare = TestCase $ do
    assertEqual "Should calculate score for Spare frame" 13 (frameScore (Spare 5 5))

testFrameScoreStrike :: Test
testFrameScoreStrike = TestCase $ do
    assertEqual "Should calculate score for Strike frame" 17 (frameScore (Strike 3 4))

-- Test cases for score
testScore :: Test
testScore = TestCase $ do
    assertEqual "Should calculate total score for frames" 30 (score [Open 3 4, Spare 5 5, Strike 3 4])

-- Test cases for scorePlay
testScorePlayValid :: Test
testScorePlayValid = TestCase $ do
    assertEqual "Should calculate score for valid play" (Just 30) (scorePlay [3, 4, 5, 5, 10, 3, 4])

testScorePlayInvalid :: Test
testScorePlayInvalid = TestCase $ do
    assertEqual "Should return Nothing for invalid play" Nothing (scorePlay [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10])

-- QuickCheck properties
prop_frameScoreIsPositive :: Frame -> Bool
prop_frameScoreIsPositive frame = frameScore frame >= 0

prop_scoreIsSumOfFrameScores :: [Frame] -> Bool
prop_scoreIsSumOfFrameScores frames = score frames == sum (map frameScore frames)

-- Running the tests
main :: IO ()
main = do
    runTestTT $ TestList
        [ testToFramesOpen
        , testToFramesSpare
        , testToFramesStrike
        , testToFramesInvalid
        , testFrameScoreOpen
        , testFrameScoreSpare
        , testFrameScoreStrike
        , testScore
        , testScorePlayValid
        , testScorePlayInvalid
        ]
    quickCheck prop_frameScoreIsPositive
    quickCheck prop_scoreIsSumOfFrameScores