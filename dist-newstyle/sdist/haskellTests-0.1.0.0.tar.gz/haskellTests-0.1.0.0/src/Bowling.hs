module Bowling (scorePlay, toFrames, Frame(..)) where

data Frame = Open Int Int
           | Spare Int Int
           | Strike Int Int
           deriving (Eq, Show)

toFrames :: [Int] -> Maybe [Frame]
toFrames xs = go 1 xs
  where
    go :: Int -> [Int] -> Maybe [Frame]
    -- Caso base para cuando se llega al 10º frame y solo tenemos 2 lanzamientos
    go 10 [x, y] = Just [Open x y]  -- frame abierto
    go 10 [x, y, z]
      | x == 10 = Just [Strike y z]   -- strike
      | x + y == 10 = Just [Spare x z]  -- spare
      | otherwise = Nothing
    -- Caso recursivo para los frames intermedios
    go n (x:y:z:ys)
      | x == 10 = (Strike y z :) <$> go (n + 1) (z : ys)   -- si es un strike
      | x + y == 10 = (Spare x z :) <$> go (n + 1) (z : ys)  -- si es un spare
      | x + y < 10 = (Open x y :) <$> go (n + 1) (z : ys)    -- frame abierto
      | otherwise = Nothing
    -- Si no se puede generar un frame válido, devolvemos Nothing
    go _ _ = Nothing

frameScore :: Frame -> Int
frameScore (Open x y) = x + y
frameScore (Spare _ y) = 10 + y
frameScore (Strike x y) = 10 + x + y

score :: [Frame] -> Int
score = sum . map frameScore

scorePlay :: [Int] -> Maybe Int
scorePlay pins = do
  frames <- toFrames pins
  return $ score frames
